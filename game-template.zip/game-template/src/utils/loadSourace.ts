export const preloadSceneAssets = {
  title: require("../assets/images/title.png"),
  "start-button": require("../assets/images/start-button.png"),
  instructions: require("../assets/images/instructions.png"),
  background: require("../assets/images/background.png"),
  ground: require("../assets/images/ground.png"),
  gameover: require("../assets/images/gameover.png"),
  score: require("../assets/audio/score.wav"),
  "ground-hit": require("../assets/audio/ground-hit.wav"),
  "pipe-hit": require("../assets/audio/pipe-hit.wav"),
};
