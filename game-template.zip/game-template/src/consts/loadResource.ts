export enum loadResource {
  title = "title",
  "start-button" = "start-button",
  instructions = "instructions",
  background = "background",
  ground = "ground",
  gameover = "gameover",
  score = "score",
  "ground-hit" = "ground-hit",
  pipes = "pipes",
  "bird" = "bird",
  "pipe-hit" = "pipe-hit",
}
