export enum SceneEnum {
  load = "loading-scene",
  gameStart = "gameStart-scene",
  gameOver = "gameOver-scene",
}
