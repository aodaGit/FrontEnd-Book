import { Game, Scale, WEBGL } from "phaser";
import GameOverScene from "./scenes/GameOverScene";
import GameStartScene from "./scenes/GameStartScene";
import PreloadScene from "./scenes/PreloadScene";

export const GameConfig: Phaser.Types.Core.GameConfig = {
  // 选择渲染的方式
  type: WEBGL,
  title: "Candy crush",
  version: "2.0",
  width: 288,
  height: 505,
  parent: "game",
  scene: [PreloadScene, GameStartScene, GameOverScene],
  render: { pixelArt: true, antialias: true },
  // 设置重力
  physics: {
    default: "arcade",
    arcade: {
      gravity: { y: 600 },
      debug: false,
    },
  },
  // 背景颜色
  // backgroundColor: "#9bd4c3",
  // scale: {
  //   mode: Scale.ScaleModes.NONE,
  //   width: window.innerWidth,
  //   height: window.innerHeight,
  // },

  callbacks: {
    // 游戏开始前的回调
    preBoot(game) {
      // console.log('游戏开始',game);
      // game.config.width=1000
    },
    // 游戏运行时的回调
    postBoot: () => {
      // console.log("游戏启动");
      // sizeChanged();
    },
  },
  // 动态设置画布大小
  // canvasStyle: `display: block; width: 100%; height: 100%;`,
  autoFocus: true,
  audio: {
    disableWebAudio: false,
  },
  // winScore: 100,
};

function sizeChanged() {
  if (window.game.isBooted) {
    setTimeout(() => {
      window.game.scale.resize(window.innerWidth, window.innerHeight);

      window.game.canvas.setAttribute(
        "style",
        `display: block; width: ${window.innerWidth}px; height: ${window.innerHeight}px;`
      );
    }, 100);
  }
}

// window.onresize = () => sizeChanged();
window.game = new Game(GameConfig);
