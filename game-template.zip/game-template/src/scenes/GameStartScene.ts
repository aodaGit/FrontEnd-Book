import { SceneEnum } from "./../consts/scene";
import Phaser from "phaser";
import { GameConfig } from "..";
import { loadResource } from "../consts/loadResource";

export default class GameStartScene extends Phaser.Scene {
  private OVER: boolean = false;
  topY!: any;
  bottomY!: any;
  rd!: number;
  player: Record<string, any> = {};
  scoreText!: any;
  score: number = 0;
  pipesX: number = Number(GameConfig.width);
  platforms!: any;
  ground!: any;
  bg: Record<string, any> = {};
  bgSpeed: number = 0;
  groundSpeed!: 0;
  platformsSpeed: number = -200;
  pipesW: number = 54;
  constructor() {
    super(SceneEnum.gameStart);
  }

  //创建水管
  createPipes = () => {
    /** 水管创建范围
     * x 100-135 y 上-30-30,下390-450
     */
    this.rd = Phaser.Math.Between(100, 135);
    const topY = Phaser.Math.Between(-40, 20);
    const bottomY = Phaser.Math.Between(380, 440);
    this.pipesX += this.rd;
    //上水管
    this.platforms.create(this.pipesX, topY, loadResource.pipes);
    //下水管
    this.platforms.create(this.pipesX, bottomY, loadResource.pipes, 1);
    //循环子组件设置重力为false
    this.platforms.children.iterate(function (child: {
      body: { allowGravity: boolean };
    }) {
      child.body.allowGravity = false;
    });
    // 水管间隙
    if (this.platforms.children.size < 4) {
      this.createPipes();
    }
  };

  create = () => {
    console.log("开始游戏");
    var that = this;
    //添加物理物体组
    this.platforms = this.physics.add.group();
    this.platforms.enableBody = true;
    this.createPipes();
    //添加静态物理精灵
    this.ground = this.add.tileSprite(
      Number(GameConfig.width) - 335 / 2,
      Number(GameConfig.height) - 112 / 2,
      335,
      112,
      loadResource.ground
    );
    this.ground = this.physics.add.existing(this.ground, true);
    // 当前游戏分数
    this.scoreText = this.add.text(10, 10, `${this.score}`);
    this.scoreText.setFontSize(40);
    //添加有重力的游戏角色
    const player = this.physics.add.sprite(100, 100, loadResource.bird);
    //添加按下事件监听
    this.input.on("pointerdown", () => {
      if (this.OVER) return;
      this.tweens.add({
        targets: player,
        duration: 50,
        angle: -30,
      });
      //设置角色Y轴速度
      player.setVelocityY(-300);
    });
    // 角色飞行动画
    player.anims.play("fly");
  };
  update(): void {
    var that = this;
    // 背景地面无限滚动
    if (!this.OVER) {
      this.bgSpeed += 0.5;
      this.groundSpeed += 5;
      this.bg.tilePositionX = this.bgSpeed;
      this.ground.tilePositionX = this.groundSpeed;
      this.updatePipes(this);
      this.platforms.setVelocityX(this.platformsSpeed);
      //判断角色下降角度
      if (this.player.angle < 90) this.player.angle += 2.5;
      this.physics.resume();
    } else {
      this.physics.pause();
    }
    //添加碰撞
    // @ts-ignore
    this.physics.add.overlap(this.player, this.platforms, () => {
      if (this.OVER) return;
      that.sound.play(loadResource["pipe-hit"]);
      this.gameOver();
    });
    // @ts-ignore
    this.physics.add.collider(this.player, this.ground, () => {
      if (this.OVER) return;
      that.sound.play(loadResource["ground-hit"]);
      this.gameOver();
    });
  }

  gameOver = () => {
    this.OVER = true;
    this.score = 0;
    this.bgSpeed = 0;
    this.groundSpeed = 0;
    this.pipesX = Number(GameConfig.width);
    this.player.anims.stop("fly");
    this.platforms.setVelocityX(0);
    this.scene.start(SceneEnum.gameOver);
  };

  //更新水管位置
  updatePipes = (that: this) => {
    this.platforms.children.iterate(
      (child: {
        body: {
          x: number;
          y: number;
          reset: (arg0: string | number | undefined, arg1: any) => void;
        };
      }) => {
        if (child.body.x < -this.pipesW) {
          this.topY = Phaser.Math.Between(-60, 0);
          this.bottomY = Phaser.Math.Between(400, 460);
          if (child.body.y < 20) {
            this.score++;
            this.scoreText.setText(this.score);
            that.sound.play(loadResource.score);
            child.body.reset(GameConfig.width, this.topY);
          } else {
            child.body.reset(GameConfig.width, this.bottomY);
          }
        }
      }
    );
  };
}
