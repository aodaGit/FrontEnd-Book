// 预加载资源场景
import Phaser from "phaser";
import { GameConfig } from "..";
import { loadResource } from "../consts/loadResource";
import { SceneEnum } from "../consts/scene";
export default class ProloadScene extends Phaser.Scene {
  bg: any;
  constructor() {
    super(SceneEnum.load);
  }
  // loding动画和函数
  loadFn() {
    const width = this.cameras.main.width;
    const height = this.cameras.main.height;
    const loadingText = this.make.text({
      x: width / 2,
      y: height / 2 - 50,
      text: "Loading...",
      style: {
        font: "20px monospace",
      },
    });
    loadingText.setOrigin(0.5, 0.5);

    const percentText = this.make.text({
      x: width / 2,
      y: height / 2 - 5,
      text: "0%",
      style: {
        font: "18px monospace",
      },
    });
    percentText.setOrigin(0.5, 0.5);

    this.load.on("progress", function (value: number) {
      // @ts-ignore
      percentText.setText(parseInt(value * 100) + "%");
    });
    this.load.on("complete", function () {
      loadingText.destroy();
      percentText.destroy();
    });
  }

  preload() {
    this.load.baseURL = "src/assets/";
    // 加载图片资源
    this.load.image(loadResource.title, "images/title.png");
    this.load.image(loadResource["start-button"], "images/start-button.png");
    this.load.image(loadResource.instructions, "images/instructions.png");
    this.load.image(loadResource.background, "images/background.png");
    this.load.image(loadResource.ground, "images/ground.png");
    this.load.image(loadResource.gameover, "images/gameover.png");
    // //加载音效
    this.load.audio(loadResource.score, "audio/score.wav");
    this.load.audio(loadResource["ground-hit"], "audio/ground-hit.wav");
    this.load.audio(loadResource["pipe-hit"], "audio/pipe-hit.wav");
    //加载雪碧图资源
    this.load.spritesheet(loadResource.pipes, "images/pipes.png", {
      // frameWidth: pipesW,
      frameWidth: 54,
      frameHeight: 320,
    });
    this.load.spritesheet(loadResource.bird, "images/bird.png", {
      frameWidth: 34,
      frameHeight: 24,
    });
    this.loadFn.call(this);
  }

  // 游戏准备
  create() {
    // 添加背景进画布
    this.bg = this.add.tileSprite(
      Number(GameConfig.width) / 2,
      Number(GameConfig.height) / 2,
      Number(GameConfig.width),
      Number(GameConfig.height),
      loadResource.background
    );
    const title = this.add.image(Number(GameConfig.width) / 2, 100, "title");
    const instructions = this.add.image(
      Number(GameConfig.width) / 2,
      Number(GameConfig.height) / 2,
      loadResource.instructions
    );
    const startButton = this.add
      .image(
        Number(GameConfig.width) / 2,
        Number(GameConfig.height) - 100,
        loadResource["start-button"]
      )
      .setInteractive();
    //添加动画
    this.anims.create({
      key: "fly",
      frames: this.anims.generateFrameNumbers(loadResource.bird, {
        start: 0,
        end: 2,
      }),
      frameRate: 10,
      repeat: -1,
    });

    startButton.on("pointerdown", () => {
      // 开始计量游玩次数
      localStorage.setItem("number", "10");
      title.destroy();
      startButton.destroy();
      instructions.destroy();
      // 启动游戏场景
      this.scene.start(SceneEnum.gameStart);
    });
  }
}
