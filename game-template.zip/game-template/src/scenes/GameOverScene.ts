import Phaser from "phaser";
import { GameConfig } from "..";
import { loadResource } from "../consts/loadResource";
import { SceneEnum } from "../consts/scene";

export default class GameOverScene extends Phaser.Scene {
  rd!: number;
  player!: any;
  scoreText!: any;
  score!: number;
  pipesX!: any;
  platforms!: any;
  constructor() {
    super(SceneEnum.gameOver);
  }

  preload = () => {};
  create = () => {
    const title = this.add.image(
      Number(GameConfig.width) / 2,
      100,
      loadResource.gameover
    );
    const startButton = this.add
      .image(
        Number(GameConfig.width) / 2,
        Number(GameConfig.height) - 100,
        loadResource["start-button"]
      )
      .setInteractive();
    // var that = this;
    startButton.on("pointerdown",  () => {
      // const OVER = false;
      title.destroy();
      startButton.destroy();
      //1.有重力bug
      // platforms.clear(true)
      // player.destroy()
      // ground.destroy()
      // scoreText.destroy()
      // game.scene.start('gameStartScene');
      // 2.临时补救方法
      this.restart();
    });
  };
  restart = () => {
    this.rd = Phaser.Math.Between(100, 135);
    this.pipesX += this.rd;
    this.platforms.children.entries[0].body.reset(
      this.pipesX,
      Phaser.Math.Between(-40, 30)
    );
    this.platforms.children.entries[1].body.reset(
      this.pipesX,
      Phaser.Math.Between(390, 440)
    );
    this.platforms.children.entries[2].body.reset(
      this.pipesX + this.rd,
      Phaser.Math.Between(-40, 30)
    );
    this.platforms.children.entries[3].body.reset(
      this.pipesX + this.rd,
      Phaser.Math.Between(390, 440)
    );
    this.player.x = 100;
    this.player.y = 100;
    this.player.angle = 0;
    this.player.anims.play("fly");
    this.scoreText.setText(this.score);
    this.scene.resume(SceneEnum.gameStart);
  };
}
