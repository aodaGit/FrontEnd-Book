interface Window {
    game: Phaser.Game;
  }
